Repository Link: https://github.com/rmit-fsd-2024-s1/s3732878-s4081498-a1.git

Before you start: 
- npm install swiper
- npm install react-icons

Reference:
    [1] “Conent of About Page”, Harvard Health Publishing, https://www.health.harvard.edu/blog/phytonutrients-paint-your-plate-with-the-colors-of-the-rainbow-2019042516501 (accessed April. 8, 2024). 
    
