import './App.css';
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Navbar from './fragments/Navbar';
import Footer from './fragments/Footer';
import Signin from './pages/Signin';
import Login from './pages/Login';
import Profile from './pages/Profile';
import Shop from './pages/Shop';
import Cart from './pages/Cart';
import About from './pages/About';
import Special from './pages/Special';
// import Diet from './pages/Diet';

import { getUser, logOut , checkRememberMe, resetCart} from "./data/repository";
import React, { useState } from 'react';


function App() {
  const [username, setUsername] = useState(getUser(null));
  const [rememberMe, setRememberMe] = useState(checkRememberMe());
  const loginUser = (username) => {
    setUsername(username);
  }

  const logoutUser = () => {
    logOut();
    setUsername(null);
    resetCart();
  }

  return (
    <div className="App">
      <Router>
        <Navbar username={username} logoutUser={logoutUser}/>
        {/* <Login2/> */}
        <main role="main">
          <div className="container my-3">
            <Routes>
              <Route path="/" element={<Special/>} />
              <Route path="/login" element={<Login loginUser={loginUser} rememberMe = {rememberMe}/>} />
              <Route path="/signin" element={<Signin/>} />
              <Route path="/profile" element={<Profile logoutUser = {logoutUser}/>} />
              <Route path="/shop" element={<Shop/>} />
              <Route path="/cart" element={<Cart/>} />
              <Route path="/about" element={<About/>} />
              {/* <Route path="/diet" element={<Diet/>} /> */}
            </Routes>
          </div>
        </main>
        <Footer username={username}/>
      </Router>
    </div>
  );
}

export default App;
