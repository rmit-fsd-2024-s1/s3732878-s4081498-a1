import React, {useState} from 'react';
import "./CardStyles.css";
import { FaCartShopping } from "react-icons/fa6";
import { FaPlus } from "react-icons/fa";
import { FaMinus } from "react-icons/fa";
import { addToCart, getSpecial } from "../data/repository";
import { RiDiscountPercentFill } from "react-icons/ri";
import { Link } from "react-router-dom";


function Card(props){
    const item = props.item;
    const [quantity, setQuantity] = useState(1);
    const specialItems = getSpecial();
    let isSpecial = false;

    const quantityPlus = () =>{
        const prevQuantity = quantity;
        setQuantity(prevQuantity + 1);
    }
    const quantityMinus = () =>{
        const prevQuantity = quantity;
        if(prevQuantity > 1) setQuantity(prevQuantity - 1);
    }
    const toCart = () => {
        if(isSpecial){
            addToCart(item.name, item.description, quantity, (item.price * (1 - props.discountRate/100) * quantity), item.imageSrc);
        }
        else{
            addToCart(item.name, item.description, quantity, item.price * quantity, item.imageSrc); 
        }
        alert("Add to cart successfully!");
    }
    const isSpecialItem = () => {
        let specialItem = [];
        specialItem = specialItems.filter((special) => special.name === item.name);
        if(specialItem.length === 1){
            isSpecial = true;
        }
    }
   
    isSpecialItem();

    return(
        <div className="card-wrapper">
            {/* <Link to={`/detail?itemName=${item.name}`}><img src = {item.imageSrc} alt ="Image"/></Link> */}
            <img src = {item.imageSrc} alt ="Image"/>
            <button id = "cart-icon" onClick={toCart}><FaCartShopping/></button>
            <div id={isSpecial ? 'discount-icon' : 'non-discount-icon'}>
                {isSpecial && < RiDiscountPercentFill/>}
            </div>
            <h1>{item.name}</h1>
            <p>{item.description}</p>
            <div className="card-buttons">
                <button onClick={quantityMinus}><FaMinus/></button>
                <p>{quantity}</p>
                <button onClick={quantityPlus}><FaPlus/></button>
                {isSpecial ? 
                    <p style={{ color: "red" }}>{`$${(item.price * (1 - props.discountRate/100) * quantity).toFixed(1)}`}</p>
                    :
                    <p>{`$${(item.price * quantity).toFixed(1)}`}</p>
                }
            </div>
        </div>
    );
}

export default Card;