import React from "react";
import "./FooterStyles.css";
import { Link } from "react-router-dom";

function Footer(props){

    return(
        <div>
            <footer>
                <hr></hr>
                <div className="footerContainer">
                    <div id="snsIcons">
                        <img src="./facebook.png" alt="facebook" ></img>
                        <img src="./instagram.png" alt="instagram" ></img>
                        <img src="./google.png" alt="google" ></img>
                    </div>
                </div>
                <div id="footerNav">
                    <ul>
                    <li><Link to="/">Home</Link></li>
                        <li><Link to="/shop">Shop</Link></li>
                        <li><Link to="/about">About</Link></li>
                        {props.username === null ? 
                            <li><Link to={"/login"}>Login</Link></li>
                            :
                            <>
                                <li><Link to={"/profile"}>My Profile</Link></li>
                                <li><Link to={"/cart"}>My Cart</Link></li>
                            </>
                        }
                    </ul>
                </div>
                <div id="footerBottom">
                    <p>Copyright  © 2024; Designed by Full Stack Development Team</p>
                </div>
            </footer>
        </div>
    );
}

export default Footer;