const USERS_KEY = "users";
const USER_KEY = "user";
const REMEMBER_ME_KEY = "rememberMe";
const ITEMS_KEY = "items";
const CART_KEY = "cart";
const SPECIAL_KEY = "specials";
const DISCOUNT_KEY = "discount";

//----------------------------------------------------------------------------------- users
// Initialise local storage "users" with data
function initUsers() {
  // Stop if data is already initialised.
  if(localStorage.getItem(USERS_KEY) !== null) return;
  // Data to store into the local storage
  const users = [
    {
      username: "Master",
      email: "Master@gmail.com",
      password: "1234567890",
      phoneNumber: "1234567890",
      address: "Unit 2803, 315 La Trobe Street",
      date: "00-00-00 00:00"
    }
  ];
  // Set data into local storage.
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}
function getUsers() {
  // Extract user data from local storage.
  const data = localStorage.getItem(USERS_KEY);

  // Convert data to objects.
  return JSON.parse(data);
}
function verifyUser(email, password) {
  // Extract user data from local storage.
  const users = getUsers();
  // Compare the new accout value with existed accounts
  for(const user of users) {
    if(email === user.email && password === user.password)
    {
      setUser(email);
      return true;
    }
  }

  return false;
}
function isExistUsername(email) {
  // Extract user data from local storage.
  const users = getUsers();
  // Compare the new accout value with existed accounts
  for(const user of users) {
    if(email === user.email)
    {
      return true;
    }
  }

  return false;
}
function getUserInfo(email) {
  // Extract user data from local storage.
  const users = getUsers();
  // Compare the new accout value with existed accounts
  for(const user of users) {
    if(email === user.email)
    {
      return user;
    }
  }
  return false;
}
function setUser(username) {
    localStorage.setItem(USER_KEY, username);
}
function getUser() {
  return localStorage.getItem(USER_KEY);
}
function logOut() {
  localStorage.removeItem(USER_KEY);
}
function createUser(username, email, password, phoneNumber, address, date) {
  const users = getUsers();
  const newUser = {
    username: username,
    email: email,
    password: password,
    phoneNumber: phoneNumber,
    address: address,
    date: date
  };
  users.push(newUser);
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}
function removeUser(email){
  const data = getUsers();
  const newUsers = data.filter(item => item.email !== email);
  localStorage.setItem(USERS_KEY, JSON.stringify(newUsers));
}
function updateUser(username, email, password, phoneNumber, address, date) {
  const users = getUsers();
  const updatedUser = {
    username: username,
    email: email,
    password: password,
    phoneNumber: phoneNumber,
    address: address,
    date: date
  };
  for(let i = 0; i < users.length; i++){
    users[i] = updatedUser;
  }
 
  localStorage.setItem(USERS_KEY, JSON.stringify(users));
}
//-------------------------------------------------------------------------------rememberMe
function initRememberMe() {
  // Stop if data is already initialised.
  if(localStorage.getItem(REMEMBER_ME_KEY) !== null) return;
  // Data to store into the local storage
  const rememberMe = 
    {
      isRemember: true,
      username: "Master@gmail.com",
      password: "1234567890"
    };
  // Set data into local storage.
  localStorage.setItem(REMEMBER_ME_KEY, JSON.stringify(rememberMe));
}
function checkRememberMe() {
  const data = localStorage.getItem(REMEMBER_ME_KEY);
  return JSON.parse(data);
}
function rememberUpdate(username, password) {
  const rememberMe = {
    isRemember: true,
    username: username,
    password: password
  };
  
  localStorage.setItem(REMEMBER_ME_KEY, JSON.stringify(rememberMe));
}
function resetRemember() {
  const rememberMe = {
    isRemember: false,
    username: "",
    password: ""
  };
  
  localStorage.setItem(REMEMBER_ME_KEY, JSON.stringify(rememberMe));
}
// ----------------------------------------------------------------------------------items
function initItems() {
  // Stop if data is already initialised.
  if(localStorage.getItem(ITEMS_KEY) !== null) return;
  // Data to store into the local storage
  const items = [
    {
      name: "Tomato",
      imageSrc: "https://images.unsplash.com/photo-1561136594-7f68413baa99?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      description: "Field Tomatoes Loose | $6.90 per 1kg",
      category: "red",
      price: 6.90
    },
    {
      name: "Beet",
      imageSrc: "https://media.istockphoto.com/id/182175899/photo/beets.jpg?s=612x612&w=0&k=20&c=h17iUch9KJSWZy7aqAIf1wKjEMLOidTs7oUfJ2-bfXA=",
      description: "Beetroot Loose | $6.50 per 1kg",
      category: "red",
      price: 6.50
    },
    {
      name: "Cherry tomato",
      imageSrc: "https://media.istockphoto.com/id/463013353/photo/cherry-tomatoes.jpg?s=612x612&w=0&k=20&c=NzcRvgVrk4kQqtp90e494n1SnyXkjstmJywt7YwoPlg=",
      description: "Cherry Tomatoes Prepacked | 250g ($14.00 per 1kg)",
      category: "red",
      price: 3.50
    },
    {
      name: "Apple",
      imageSrc: "https://images.unsplash.com/photo-1560806887-1e4cd0b6cbd6?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8YXBwbGV8ZW58MHx8MHx8fDA%3D",
      description: "Apples Medium | $4.90 per 1kg",
      category: "red",
      price: 4.90
    },
    {
      name: "Strawberry",
      imageSrc: "https://images.unsplash.com/photo-1543158181-e6f9f6712055?q=80&w=2940&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
      description: "Strawberries prepacked | 250g ($18.00 per 1kg)",
      category: "red",
      price: 4.50
    },
    {
      name: "Raspberry",
      imageSrc: "https://images.unsplash.com/photo-1577069861033-55d04cec4ef5?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cmFzcGJlcnJpZXN8ZW58MHx8MHx8fDA%3D",
      description: "Raspberries prepacked | 125g ($36.00 per 1kg)",
      category: "red",
      price: 4.50
    },
    {
      name: "Carrot",
      imageSrc: "https://images.unsplash.com/photo-1598170845058-32b9d6a5da37?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8Y2Fycm90fGVufDB8fDB8fHww",
      description: "Carrots Loose | $2.50 per 1kg",
      category: "yellow",
      price: 2.50
    },
    {
      name: "Sweet potato",
      imageSrc: "https://media.istockphoto.com/id/172245358/photo/raw-whole-sweet-potatoes-yams-fresh-healthy-root-vegetable.jpg?s=612x612&w=0&k=20&c=OTTNlljXUgsAJS2U_1zwJSMx_OIB9fAKX7HeLMUY1HE=",
      description: "Sweet Gold Potatoes Loose | $4.50 per 1kg",
      category: "yellow",
      price: 4.50
    },
    {
      name: "Pumpkin",
      imageSrc: "https://media.istockphoto.com/id/611897918/photo/recently-harvested-orange-pumpkins-in-a-random-pile.jpg?s=612x612&w=0&k=20&c=ikw4KXAgc-ogVhK7WaQuhmUIhwNisl45c7vX5dfR1yU=",
      description: "Kent Pumpkin Whole | approx 4kg ($1.50 per 1kg)",
      category: "yellow",
      price: 6.00
    },
    {
      name: "Orange",
      imageSrc: "https://images.unsplash.com/photo-1611080626919-7cf5a9dbab5b?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8b3Jhbmdlc3xlbnwwfHwwfHx8MA%3D%3D",
      description: "Medium Navel Oranges | approx 160g ($6.90 per 1kg)",
      category: "yellow",
      price: 1.10
    },
    {
      name: "Apricot",
      imageSrc: "https://images.unsplash.com/photo-1592681814168-6df0fa93161b?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YXByaWNvdHN8ZW58MHx8MHx8fDA%3D",
      description: "Medium Navel Oranges | $6.90 per 1kg",
      category: "yellow",
      price: 6.90
    },
    {
      name: "Banana",
      imageSrc: "https://images.unsplash.com/photo-1603833665858-e61d17a86224?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YmFuYW5hc3xlbnwwfHwwfHx8MA%3D%3D",
      description: "Organic Bananas | approx 170g ($6.00 per 1kg)",
      category: "yellow",
      price: 1.02
    },
    {
      name: "Corn",
      imageSrc: "https://images.unsplash.com/photo-1559631526-5716df3cfacd?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTl8fGNvcm58ZW58MHx8MHx8fDA%3D",
      description: "Sweet Corn | 1 each)",
      category: "yellow",
      price: 1.90
    },
    {
      name: "Cantaloupe",
      imageSrc: "https://plus.unsplash.com/premium_photo-1675040830254-1d5148d9d0dc?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8Y2FudGFsb3VwZXxlbnwwfHwwfHx8MA%3D%3D",
      description: "Rockmelon Whole | 1 each",
      category: "yellow",
      price: 5.90
    },
    {
      name: "Butternut",
      imageSrc: "https://images.unsplash.com/photo-1602403796307-4bc550d59e8d?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8M3x8YnV0dGVybnV0fGVufDB8fDB8fHww",
      description: "Butternut Pumpkin Whole | approx 2Kg",
      category: "yellow",
      price: 7.00
    },
    {
      name: "Potato",
      imageSrc: "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cG90YXRvfGVufDB8fDB8fHww",
      description: "Creme Gold Washed Potatoes Loose | approx 120g ($4.50 per 1kg)",
      category: "yellow",
      price: 4.5
    },
    {
      name: "Cabbage",
      imageSrc: "https://images.unsplash.com/photo-1591586007768-40725cc562a1?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8Q2FiYmFnZXxlbnwwfHwwfHx8MA%3D%3D",
      description: "Half Drumhead Cabbage | 1 each",
      category: "green",
      price: 7.4
    },
    {
      name: "Spinach",
      imageSrc: "https://media.istockphoto.com/id/157330429/photo/baby-spinach.jpg?s=612x612&w=0&k=20&c=B7m9Orx_E5gNoj1XNYGdL3NXPzEqwi8DBAYoYGL6R7M=",
      description: "Baby Spinach prepacked | 60g ($33.34 per 1kg)",
      category: "green",
      price: 2.00
    },
    {
      name: "Broccoli",
      imageSrc: "https://media.istockphoto.com/id/147060621/photo/broccoli.jpg?s=612x612&w=0&k=20&c=I1cCxLxci23nrSNZb7o6gsqUYB911z6IZlLdEOk4I9M=",
      description: "Broccoli | approx 340g ($5.90 per 1kg)",
      category: "green",
      price: 5.90
    },
    {
      name: "Cucumber",
      imageSrc: "https://media.istockphoto.com/id/478377196/photo/cucumber-background.jpg?s=612x612&w=0&k=20&c=0NqGsgxFI231tSmPZb4lmAFdLCFnLlc1TiA-3ZvgoMc=",
      description: "Continental Cucumbers Loose | 1 each",
      category: "green",
      price: 2.90
    },
    {
      name: "Asparagus",
      imageSrc: "https://images.unsplash.com/photo-1629875235163-2e52306e4018?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8YXNwYXJhZ3VzfGVufDB8fDB8fHww",
      description: "Green Asparagus | 10 each",
      category: "green",
      price: 3.20
    },
    {
      name: "Blueberry",
      imageSrc: "https://images.unsplash.com/photo-1594002348772-bc0cb57ade8b?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8Ymx1ZWJlcnJpZXN8ZW58MHx8MHx8fDA%3D",
      description: "Very delicious blueberry",
      category: "blue",
      price: 5.99
    },
    {
      name: "Blackberry",
      imageSrc: "https://images.unsplash.com/photo-1565464062470-b8cb4468776e?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTJ8fGJsYWNrYmVycmllc3xlbnwwfHwwfHx8MA%3D%3D",
      description: "Coles Blackberries Prepacked | 125g ($40.00 per 1kg)",
      category: "blue",
      price: 5.00
    },
    {
      name: "Eggplant",
      imageSrc: "https://images.unsplash.com/photo-1605197378540-10ebaf6999e5?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NHx8ZWdncGxhbnR8ZW58MHx8MHx8fDA%3D",
      description: "Purple Eggplant | approx 500g ($5.90 per 1kg)",
      category: "blue",
      price: 2.95
    },
    {
      name: "Plum",
      imageSrc: "https://images.unsplash.com/photo-1568477070800-66719cd52be2?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8cGx1bXN8ZW58MHx8MHx8fDA%3D",
      description: "Plums Red | $4.90 per 1kg",
      category: "blue",
      price: 4.90
    },
    {
      name: "Fig",
      imageSrc: "https://images.unsplash.com/photo-1635341814161-d696d538542c?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTF8fGZpZ3N8ZW58MHx8MHx8fDA%3D",
      description: " Figs | approx $5.90 per 1kg",
      category: "blue",
      price: 5.90
    },
    {
      name: "Onion",
      imageSrc: "https://images.unsplash.com/photo-1580201092675-a0a6a6cafbb1?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8b25pb258ZW58MHx8MHx8fDA%3D",
      description: "Brown Onions loose | $3.60 per 1kg",
      category: "white",
      price: 3.60
    },
    {
      name: "Garlic",
      imageSrc: "https://media.istockphoto.com/id/504127168/photo/garlic.jpg?s=1024x1024&w=is&k=20&c=Dd6kFGRCJvxc8-7P9Z_ISk3aU0Ug1dCXcDHJAQJTmBE=",
      description: "Garlic loose | approx 60g ($29.00 per 1kg)",
      category: "white",
      price: 1.74
    },
    {
      name: "Cauliflower",
      imageSrc: "https://images.unsplash.com/photo-1566842600175-97dca489844f?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8Y2F1bGlmbG93ZXJ8ZW58MHx8MHx8fDA%3D",
      description: "Whole cauliflower | 1 each",
      category: "white",
      price: 6.60
    },
    {
      name: "Leek",
      imageSrc: "https://images.unsplash.com/photo-1692956706365-f4392b139c10?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mjh8fGxlZWtzfGVufDB8fDB8fHww",
      description: "Leeks | 1 each",
      category: "white",
      price: 2.90
    },
    {
      name: "Parsnip",
      imageSrc: "https://images.unsplash.com/photo-1648291913186-951f2ef36c85?w=900&auto=format&fit=crop&q=60&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8N3x8cGFyc25pcHN8ZW58MHx8MHx8fDA%3D",
      description: "Parsnips Loose | approx 140g ($12.00 per 1kg)",
      category: "white",
      price: 1.68
    },
    
  ];
  // Set data into local storage. 
  localStorage.setItem(ITEMS_KEY, JSON.stringify(items));
}
function getItems() {
  const data = localStorage.getItem(ITEMS_KEY);
  return JSON.parse(data);
}
function findItem(name){
    const data = getItems();
    let tmp = null;
    for(let i = 0; i< data.length; i++){
      if(data[i].name === name){
        tmp = data[i];
        break;
      }
    }
    return tmp;
}
//----------------------------------------------------------------------------------Special
function initSpecial() {
  // Data to store into the local storage
  const specials = getWeekSpecial();
  // Set data into local storage.
  localStorage.setItem(SPECIAL_KEY, JSON.stringify(specials));
}
function getSpecial() {
  const data = localStorage.getItem(SPECIAL_KEY);
  return JSON.parse(data);
}
function getWeekSpecial() {
  const arr = getItems();
  let result = [];
  let len = arr.length;
    
  while (result.length < 5) {
    let randomIndex = Math.floor(Math.random() * len);
    if(arr[randomIndex] in result){
      continue;
    }
    result.push(arr[randomIndex]);
  }

  return result;
}
function setDiscount() {
  const discountRate = (Math.floor(Math.random() * 4) + 1)*10;
  localStorage.setItem(DISCOUNT_KEY, discountRate);
}
function getDiscount(){
  return localStorage.getItem(DISCOUNT_KEY);
}
//--------------------------------------------------------------------------------------cart
function initCart() {
  const cart = [];
  // Set data into local storage.
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}
function getCart() {
  const data = localStorage.getItem(CART_KEY);
  return JSON.parse(data);
}
function addToCart(name, description, quantity, price, imageSrc) {
  const cart = getCart();

  const newItem = {
    name: name,
    description: description,
    quantity: quantity,
    price: price,
    imageSrc: imageSrc
  };
  cart.push(newItem);
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}
function updateCart(name) {
  const cart = getCart();

  const newCart = cart.filter(item => item.name !== name);
  localStorage.setItem(CART_KEY, JSON.stringify(newCart));
}
function resetCart(){
  const cart = [];
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
}


export {
  initUsers,
  verifyUser,
  isExistUsername,
  getUser,
  logOut,
  createUser,
  removeUser,
  updateUser,
  initRememberMe,
  checkRememberMe,
  rememberUpdate,
  resetRemember,
  initItems,
  getItems,
  findItem,
  initCart,
  getCart,
  addToCart,
  updateCart,
  resetCart,
  initSpecial,
  getWeekSpecial,
  getSpecial,
  setDiscount,
  getDiscount,
  getUserInfo
}
