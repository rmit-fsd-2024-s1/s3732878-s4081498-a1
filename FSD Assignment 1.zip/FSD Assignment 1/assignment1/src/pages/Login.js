import "./LoginStyles.css";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { verifyUser , checkRememberMe, rememberUpdate, resetRemember} from "../data/repository";
import { Link } from "react-router-dom";
import { FaUser } from "react-icons/fa";
import { FaLock } from "react-icons/fa";


function Login(props){
    const [remember, setRemember] = useState(checkRememberMe);
    const [fields, setFields] = useState({ username: remember.username, password: remember.password });
    const [errorMessage, setErrorMessage] = useState(null);
    const navigate = useNavigate();
    // Generic change handler.
    const handleInputChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        // Copy fields.
        const temp = { ...fields };

        // Update field and state.
        temp[name] = value;
        setFields(temp);
        if(name === "eamil"){
            props.loginUser(fields.email);
        }
    }

    const tryLogin = (event) => {
        event.preventDefault();

        const verified = verifyUser(fields.username, fields.password);

        // If verified login the user.
        if(verified === true) {
            
            props.loginUser(fields.email);

            // Navigate to the profile page.
            alert("Login Successfully!");
            navigate("/shop");

            if(remember.isRemember === true){
                // Setting rememberMe with userName, password and value of true;
                rememberUpdate(fields.username, fields.password);
            }
            else{
                // Resetting rememberMe;
                resetRemember();
            }
        return;
        }

        // Reset password field to blank. (If not verified login the user)
        const temp = { ...fields }; // Leave username
        temp.password = "";         // but reset password
        setFields(temp);

        // Set error message.
        setErrorMessage("Username and / or password invalid, please try again.");
    }
    const changeCheckBox=(event)=>{
        const temp = { ...remember };
        temp.isRemember = event.target.checked;
        setRemember(temp);
    }

    return(
        <div className = "login-box">
            <div className = "login-wrapper">
            <form onSubmit={tryLogin}>
                <h1>Login</h1>
                <div className = "input-field">
                    <input type = "text" placeholder="Username" required 
                    name="username" id="username"
                    value={fields.username} onChange={handleInputChange}/>
                    <FaUser className="icon"/>
                </div>
                <div className = "input-field">
                    <input type = "password" placeholder="Passsword" required 
                    name="password" id="password"
                    value={fields.password} onChange={handleInputChange}/>
                    <FaLock className="icon"/>
                </div>

                <div className = "remember-forgot">
                    <label><input type = "checkbox" checked = {remember.isRemember} 
                        onChange={changeCheckBox}/>Remeber me</label>
                </div>

                <button type = "submit">Login</button>
                
                {errorMessage !== null &&
                    <div id="errorMessage">
                        <span className="text-danger">{errorMessage}</span>
                    </div>
                }
            
                <div className="register-link">
                    <p> Don't have an account? <Link to="/Signin">Sign-in</Link></p>
                </div>
            </form>
        </div>
        </div>
    );
}
export default Login;