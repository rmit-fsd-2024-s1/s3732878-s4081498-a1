// import { FaDisplay } from 'react-icons/fa6';
import './ProfileStyles.css';
import { useRef, useState } from 'react';
import { useNavigate } from "react-router-dom";
import { getUserInfo, updateUser, getUser, removeUser } from '../data/repository';


function Profile(props) {
  
  const inputRef = useRef(null)
  const [image, setImage] = useState("")
  
  const [user, setUser] = useState(getUserInfo(getUser()));  
  const [isEditing, setIsEditing] = useState(false);
  const [isStrong, setIsStrong] = useState(null);
  const [isCorrectForm, setIsCorrectFoem] = useState(null);
  const navigate = useNavigate();


  const handleImgaeClick = () => {
    inputRef.current.click();
  };
  const handleImageChange = (event) => {
    const file =event.target.files[0];
    console.log(file);
    setImage(event.target.files[0]);
  };
  const handleInputChange = (event) => {
    const name = event.target.name;
    const value = event.target.value;
    // Copy fields.
    const temp = { ...user };

    // Update field and state.
    temp[name] = value;
    setUser(temp);
  }
  const passwordIsStrong = (password) => {
    let alphabetCount = 0;
    let numberCount = 0;
    let specialCount = 0;

    for (let i = 0; i < password.length; i++) {
        const char = password[i];
        if (/[a-zA-Z]/.test(char)) {
            alphabetCount++;
        } else if (/[0-9]/.test(char)) {
            numberCount++;
        } else {
            specialCount++;
        }
    }
    if(alphabetCount === 0 || numberCount === 0 || specialCount === 0){
        setIsStrong("The password must be a combination of numbers, alphabets, and special characters.");
        return;
    }
    // Check if password is longer than 12
    if(password.length < 12 ){
        setIsStrong("The password must be longer than or equal 12");
        return false;
    }
    // Check if password contains at least one upper letter
    if(password === password.toLowerCase()){
        setIsStrong("The password must contain at least one upper letter");
        return false;
    }
    return true;
}
const checkPhoneNumberForm = (phoneNumber) => {
  const phoneNumberPattern = /^\d{10}$/;
  if(phoneNumberPattern.test(phoneNumber)) return true;
  else {
    setIsCorrectFoem("The phone number must be a 10-digit number.");
    return false;
  }
}
const updateAccount = (event) => {
    event.preventDefault();
    // Check user put the same value on password input and checkPassword input
    if(!passwordIsStrong(user.password)){
        return;
    }
    if(!checkPhoneNumberForm(user.phoneNumber)){
      return;
    }
    updateUser(user.username, user.email, user.password, user.phoneNumber, user.address, user.date);
    alert("User information is updated.")
}
const deleteAccount = () => {
  removeUser(user.email);
  props.logoutUser();
  navigate("/login");
}

  return (
    <div className = "profile-box">
    <div class="profile-wrapper">
      <h1>User Profile</h1> 
      <div class = 'text_box'>
        <div className="profile-image" onClick={handleImgaeClick}>
          {image ? <img class = 'img_deg' src = {URL.createObjectURL(image)} alt=""/> : <img class = 'img_deg' src = "./google.png" alt=""/>}
          <input type="file" ref={inputRef} onChange={handleImageChange} style={{display:'none'}}/>
        </div>
        <ul class = 'profile-list'>
          <li><h1> User Information</h1></li>
          <li>Date of joining: {user.date}</li>
          <li>User Name: {user.username}</li>
          <li>
            <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Email Address: {user.email}
              </label> 
            </form>
          </li>
          <li>
          <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Password:
                <input type = "text" required 
                    name="password" id="password"
                    value={user.password} onChange={handleInputChange}/>
              </label>  
            </form>
          </li>
          <li>
            <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Phone Number:{""}
                <input type = "text" inputMode='numberic' required 
                    name="phoneNumber" id="phoneNumber"
                    value={user.phoneNumber} onChange={handleInputChange}/>
              </label>  
            </form>
            
          </li>
          <li>
            <form onSubmit={(e) => {
              e.preventDefault();
              setIsEditing(!isEditing);
            }}>
              <label>
                Home Adress:{""}
                <input type = "text" required 
                    name="address" id="address"
                    value={user.address} onChange={handleInputChange}/>
              </label>
              <div class = 'profile-button'>
              <div className="errorMessage">
                <span>{isStrong}</span>
              </div>
              <div className="errorMessage">
                <span>{isCorrectForm}</span>
              </div>
                <button onClick={updateAccount} id = 'button1'>Save Profile</button>
                <button onClick={deleteAccount} id = 'button2'>Delete Account</button>
              </div> 
            </form>
          </li>
        </ul>
      </div>
    </div> 
    </div>
  );
}

export default Profile;