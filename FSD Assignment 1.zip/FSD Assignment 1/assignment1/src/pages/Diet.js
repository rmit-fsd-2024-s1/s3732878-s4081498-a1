import React, {useState} from 'react'
import "./DietStyles.css";



function Diet(){
    const [userInfo, setUserInfo] = useState({age: null, height: null, weight: null})
    const [activityLevel, setActivityLevel] = useState("Select");
    const [dietaryPref, setDietaryPref] = useState("Select");
    const [healthGoal, setHealthGoal] = useState("Select");

    const handleInputChange = (event) => {
        const name = event.target.name;
        const value = event.target.value;
        let temp = { ...userInfo };
        
        // Update field and state.
        temp[name] = value;
        setUserInfo(temp);
    }
    const SelectOption = (event) => {

    }
    return(
        <div className = "diet-wrapper">
            <div className = "userDiet-form">
                <h1>Diet Information</h1>
                <form>
                    <div className="diet-inputs">
                    <label for="cartNumber">Age:</label>
                    <div className = "card-number">
                        <input type = "number" placeholder="Age" required name="age" 
                        id="age" value={userInfo.age} onChange={handleInputChange}/>
                    </div>

                    <label for="cartNumber">Hight:</label>
                    <div className = "card-number">
                        <input type = "number" placeholder="Hight (cm)" required name="hight" 
                            id="hight" value={userInfo.hight} onChange={handleInputChange}/>
                    </div>

                    <label for="cartNumber">weight:</label>
                    <div className = "card-number">
                        <input type = "number" placeholder="Weight (kg)" required name="weight" 
                            id="weight" value={userInfo.weight} onChange={handleInputChange}/>
                    </div>
                    </div>
                    <div className = "diet-dropdowns">
                    <div>
                    <label for="cartNumber">Activity level</label>
                        <div class="dropdown">
                            <span class="dropbtn">{activityLevel}</span>
                            <div class="dropdown-content">
                                <p onClick = {SelectOption}>once a week exercise</p>
                                <p onClick = {SelectOption}>exercise 2-3 times a week</p>
                                <p onClick = {SelectOption}>exercise 4-5 times a week</p>
                            </div>
                        </div> 
                    </div>

                    <div>
                    <label for="cartNumber">Dietary preferences</label>
                        <div class="dropdown">
                            <span class="dropbtn">{dietaryPref}</span>
                            <div class="dropdown-content">
                                <p onClick = {SelectOption}>A carbohydrate-based meal</p>
                                <p onClick = {SelectOption}>A protein-based meal</p>
                                <p onClick = {SelectOption}>A fat-based meal</p>
                                <p onClick = {SelectOption}>A balanced meal</p>
                            </div>
                        </div> 
                    </div>

                    <div>
                    <label for="cartNumber">Health goals</label>
                        <div class="dropdown">
                            <span class="dropbtn">{healthGoal}</span>
                            <div class="dropdown-content">
                                <p onClick = {SelectOption}>weight loss</p>
                                <p onClick = {SelectOption}>muscle gain</p>
                                <p onClick = {SelectOption}>overall health improvement</p>
                            </div>
                        </div> 
                    </div>
                    </div>
                    <button type = 'submit'>Submit</button>
                </form>
           </div>
        </div>
    );
}

export default Diet;