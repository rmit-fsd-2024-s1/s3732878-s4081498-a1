import React from 'react';
// import ReactDOM from 'react-dom/client';
import ReactDOM from 'react-dom';

import './index.css';
import { initUsers, initRememberMe, initItems, initCart, initSpecial, setDiscount} from "./data/repository";
import App from './App';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root'));

initUsers();
initRememberMe();
initItems();
initCart();
initSpecial();
setDiscount();


root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
  document.getElementById("root")
);

reportWebVitals();
